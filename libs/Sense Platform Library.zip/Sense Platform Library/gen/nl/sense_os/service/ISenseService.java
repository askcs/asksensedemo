/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /home/bart/Programming/Android/Sense Platform Library/src/nl/sense_os/service/ISenseService.aidl
 */
package nl.sense_os.service;
public interface ISenseService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements nl.sense_os.service.ISenseService
{
private static final java.lang.String DESCRIPTOR = "nl.sense_os.service.ISenseService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an nl.sense_os.service.ISenseService interface,
 * generating a proxy if needed.
 */
public static nl.sense_os.service.ISenseService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof nl.sense_os.service.ISenseService))) {
return ((nl.sense_os.service.ISenseService)iin);
}
return new nl.sense_os.service.ISenseService.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_changeLogin:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
nl.sense_os.service.ISenseServiceCallback _arg2;
_arg2 = nl.sense_os.service.ISenseServiceCallback.Stub.asInterface(data.readStrongBinder());
this.changeLogin(_arg0, _arg1, _arg2);
reply.writeNoException();
return true;
}
case TRANSACTION_logout:
{
data.enforceInterface(DESCRIPTOR);
this.logout();
reply.writeNoException();
return true;
}
case TRANSACTION_register:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
java.lang.String _arg5;
_arg5 = data.readString();
java.lang.String _arg6;
_arg6 = data.readString();
java.lang.String _arg7;
_arg7 = data.readString();
java.lang.String _arg8;
_arg8 = data.readString();
nl.sense_os.service.ISenseServiceCallback _arg9;
_arg9 = nl.sense_os.service.ISenseServiceCallback.Stub.asInterface(data.readStrongBinder());
this.register(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9);
reply.writeNoException();
return true;
}
case TRANSACTION_getSessionId:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _result = this.getSessionId(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getPrefBool:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
boolean _arg1;
_arg1 = (0!=data.readInt());
boolean _result = this.getPrefBool(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getPrefFloat:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
float _arg1;
_arg1 = data.readFloat();
float _result = this.getPrefFloat(_arg0, _arg1);
reply.writeNoException();
reply.writeFloat(_result);
return true;
}
case TRANSACTION_getPrefInt:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _result = this.getPrefInt(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getPrefLong:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
long _arg1;
_arg1 = data.readLong();
long _result = this.getPrefLong(_arg0, _arg1);
reply.writeNoException();
reply.writeLong(_result);
return true;
}
case TRANSACTION_getPrefString:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _result = this.getPrefString(_arg0, _arg1);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getStatus:
{
data.enforceInterface(DESCRIPTOR);
nl.sense_os.service.ISenseServiceCallback _arg0;
_arg0 = nl.sense_os.service.ISenseServiceCallback.Stub.asInterface(data.readStrongBinder());
this.getStatus(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_setPrefBool:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
boolean _arg1;
_arg1 = (0!=data.readInt());
this.setPrefBool(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_setPrefFloat:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
float _arg1;
_arg1 = data.readFloat();
this.setPrefFloat(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_setPrefInt:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
this.setPrefInt(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_setPrefLong:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
long _arg1;
_arg1 = data.readLong();
this.setPrefLong(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_setPrefString:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
this.setPrefString(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_toggleAmbience:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
this.toggleAmbience(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_toggleDeviceProx:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
this.toggleDeviceProx(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_toggleExternalSensors:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
this.toggleExternalSensors(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_toggleLocation:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
this.toggleLocation(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_toggleMain:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
this.toggleMain(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_toggleMotion:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
this.toggleMotion(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_togglePhoneState:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
this.togglePhoneState(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_togglePopQuiz:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
this.togglePopQuiz(_arg0);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements nl.sense_os.service.ISenseService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**
     * Tries to log in at CommonSense using the supplied username and password. After login, the
     * service remembers the username and password.
     * 
     * @param username
     *            username for login
     * @param pass
     *            hashed password for login
     * @param callback 
     *            interface to receive callback when login is completed
     */
@Override public void changeLogin(java.lang.String username, java.lang.String password, nl.sense_os.service.ISenseServiceCallback callback) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(username);
_data.writeString(password);
_data.writeStrongBinder((((callback!=null))?(callback.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_changeLogin, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Logs out a user, destroying his or her records.
     */
@Override public void logout() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_logout, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * Registers a new user at CommonSense and logs in immediately.
     *
     * @param username 
     *         Username for the new user
     * @param password 
     *         Hashed password String for the new user
     * @param email 
     *         Email address
     * @param country 
     *         Country
     * @param address 
     *         Street address (optional, null if not required)
     * @param zipCode 
     *         ZIP code (optional, null if not required)
     * @param name 
     *         First name (optional, null if not required)
     * @param surname 
     *         Surname (optional, null if not required)
     * @param mobile 
     *         Phone number, preferably in E164 format (optional, null if not required)
     * @param callback 
     *         Interface to receive callback when login is completed
     */
@Override public void register(java.lang.String username, java.lang.String password, java.lang.String email, java.lang.String address, java.lang.String zipCode, java.lang.String country, java.lang.String name, java.lang.String surname, java.lang.String mobile, nl.sense_os.service.ISenseServiceCallback callback) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(username);
_data.writeString(password);
_data.writeString(email);
_data.writeString(address);
_data.writeString(zipCode);
_data.writeString(country);
_data.writeString(name);
_data.writeString(surname);
_data.writeString(mobile);
_data.writeStrongBinder((((callback!=null))?(callback.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_register, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * @param appSecret
     *         Secret identifier of the application that requests the session ID. Only certain 
     *         'safe' apps are allowed to access the session ID.
     * @return
     *         The currently active session ID for CommonSense, or null if there is no active 
     *         session
     * @throws RemoteException 
     *         If the app ID is not valid
     */
@Override public java.lang.String getSessionId(java.lang.String appSecret) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(appSecret);
mRemote.transact(Stub.TRANSACTION_getSessionId, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean getPrefBool(java.lang.String key, boolean defValue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeInt(((defValue)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_getPrefBool, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public float getPrefFloat(java.lang.String key, float defValue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
float _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeFloat(defValue);
mRemote.transact(Stub.TRANSACTION_getPrefFloat, _data, _reply, 0);
_reply.readException();
_result = _reply.readFloat();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int getPrefInt(java.lang.String key, int defValue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeInt(defValue);
mRemote.transact(Stub.TRANSACTION_getPrefInt, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public long getPrefLong(java.lang.String key, long defValue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
long _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeLong(defValue);
mRemote.transact(Stub.TRANSACTION_getPrefLong, _data, _reply, 0);
_reply.readException();
_result = _reply.readLong();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getPrefString(java.lang.String key, java.lang.String defValue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeString(defValue);
mRemote.transact(Stub.TRANSACTION_getPrefString, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public void getStatus(nl.sense_os.service.ISenseServiceCallback callback) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((callback!=null))?(callback.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_getStatus, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void setPrefBool(java.lang.String key, boolean value) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeInt(((value)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_setPrefBool, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void setPrefFloat(java.lang.String key, float value) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeFloat(value);
mRemote.transact(Stub.TRANSACTION_setPrefFloat, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void setPrefInt(java.lang.String key, int value) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeInt(value);
mRemote.transact(Stub.TRANSACTION_setPrefInt, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void setPrefLong(java.lang.String key, long value) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeLong(value);
mRemote.transact(Stub.TRANSACTION_setPrefLong, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void setPrefString(java.lang.String key, java.lang.String value) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(key);
_data.writeString(value);
mRemote.transact(Stub.TRANSACTION_setPrefString, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void toggleAmbience(boolean active) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((active)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_toggleAmbience, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void toggleDeviceProx(boolean active) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((active)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_toggleDeviceProx, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void toggleExternalSensors(boolean active) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((active)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_toggleExternalSensors, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void toggleLocation(boolean active) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((active)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_toggleLocation, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void toggleMain(boolean active) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((active)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_toggleMain, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void toggleMotion(boolean active) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((active)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_toggleMotion, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void togglePhoneState(boolean active) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((active)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_togglePhoneState, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void togglePopQuiz(boolean active) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((active)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_togglePopQuiz, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_changeLogin = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_logout = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_register = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_getSessionId = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_getPrefBool = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_getPrefFloat = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_getPrefInt = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_getPrefLong = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_getPrefString = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_getStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_setPrefBool = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_setPrefFloat = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_setPrefInt = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_setPrefLong = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_setPrefString = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_toggleAmbience = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_toggleDeviceProx = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_toggleExternalSensors = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_toggleLocation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
static final int TRANSACTION_toggleMain = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
static final int TRANSACTION_toggleMotion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
static final int TRANSACTION_togglePhoneState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
static final int TRANSACTION_togglePopQuiz = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
}
/**
     * Tries to log in at CommonSense using the supplied username and password. After login, the
     * service remembers the username and password.
     * 
     * @param username
     *            username for login
     * @param pass
     *            hashed password for login
     * @param callback 
     *            interface to receive callback when login is completed
     */
public void changeLogin(java.lang.String username, java.lang.String password, nl.sense_os.service.ISenseServiceCallback callback) throws android.os.RemoteException;
/**
     * Logs out a user, destroying his or her records.
     */
public void logout() throws android.os.RemoteException;
/**
     * Registers a new user at CommonSense and logs in immediately.
     *
     * @param username 
     *         Username for the new user
     * @param password 
     *         Hashed password String for the new user
     * @param email 
     *         Email address
     * @param country 
     *         Country
     * @param address 
     *         Street address (optional, null if not required)
     * @param zipCode 
     *         ZIP code (optional, null if not required)
     * @param name 
     *         First name (optional, null if not required)
     * @param surname 
     *         Surname (optional, null if not required)
     * @param mobile 
     *         Phone number, preferably in E164 format (optional, null if not required)
     * @param callback 
     *         Interface to receive callback when login is completed
     */
public void register(java.lang.String username, java.lang.String password, java.lang.String email, java.lang.String address, java.lang.String zipCode, java.lang.String country, java.lang.String name, java.lang.String surname, java.lang.String mobile, nl.sense_os.service.ISenseServiceCallback callback) throws android.os.RemoteException;
/**
     * @param appSecret
     *         Secret identifier of the application that requests the session ID. Only certain 
     *         'safe' apps are allowed to access the session ID.
     * @return
     *         The currently active session ID for CommonSense, or null if there is no active 
     *         session
     * @throws RemoteException 
     *         If the app ID is not valid
     */
public java.lang.String getSessionId(java.lang.String appSecret) throws android.os.RemoteException;
public boolean getPrefBool(java.lang.String key, boolean defValue) throws android.os.RemoteException;
public float getPrefFloat(java.lang.String key, float defValue) throws android.os.RemoteException;
public int getPrefInt(java.lang.String key, int defValue) throws android.os.RemoteException;
public long getPrefLong(java.lang.String key, long defValue) throws android.os.RemoteException;
public java.lang.String getPrefString(java.lang.String key, java.lang.String defValue) throws android.os.RemoteException;
public void getStatus(nl.sense_os.service.ISenseServiceCallback callback) throws android.os.RemoteException;
public void setPrefBool(java.lang.String key, boolean value) throws android.os.RemoteException;
public void setPrefFloat(java.lang.String key, float value) throws android.os.RemoteException;
public void setPrefInt(java.lang.String key, int value) throws android.os.RemoteException;
public void setPrefLong(java.lang.String key, long value) throws android.os.RemoteException;
public void setPrefString(java.lang.String key, java.lang.String value) throws android.os.RemoteException;
public void toggleAmbience(boolean active) throws android.os.RemoteException;
public void toggleDeviceProx(boolean active) throws android.os.RemoteException;
public void toggleExternalSensors(boolean active) throws android.os.RemoteException;
public void toggleLocation(boolean active) throws android.os.RemoteException;
public void toggleMain(boolean active) throws android.os.RemoteException;
public void toggleMotion(boolean active) throws android.os.RemoteException;
public void togglePhoneState(boolean active) throws android.os.RemoteException;
public void togglePopQuiz(boolean active) throws android.os.RemoteException;
}
